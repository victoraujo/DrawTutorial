//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

var myViewController = MyViewController()
// Present the view controller in the Live View window



PlaygroundPage.current.liveView = myViewController
